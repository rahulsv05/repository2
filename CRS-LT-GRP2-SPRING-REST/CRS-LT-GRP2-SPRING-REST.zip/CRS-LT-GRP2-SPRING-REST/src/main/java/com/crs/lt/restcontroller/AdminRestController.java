package com.crs.lt.restcontroller;

import com.crs.lt.dao.AdminDaoImplementation;
import com.crs.lt.model.Course;
import com.crs.lt.model.Professor;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;


import static org.apache.logging.log4j.LogManager.getLogger;

@RestController
@CrossOrigin
@RequestMapping("/api/admin")
public class AdminRestController {

    private static final Logger LOGGER = getLogger(AdminRestController.class);

    @Autowired
    private AdminDaoImplementation adminDao;

    @GetMapping("/view-course")
    public void viewCoursesByCatalogId() throws SQLException {
        try {
            adminDao.viewCoursesByCatalogId();
        }catch(Exception e){
            e.printStackTrace();
            LOGGER.error("Unable to delete Course ");
        }
    }

    @DeleteMapping("{courseCode}")
    public void deleteCourse(@PathVariable String courseCode) {
        try {
            adminDao.deleteCourse(courseCode);
            System.out.println("Course Successfully deleted");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Unable to delete Course ");
        }
    }

    @PostMapping("/add-course")
    public void addCourse(Course course) {
        try {
            adminDao.addCourse(course);
            System.out.println("Course Successfully added");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Unable to add Course");
        }
    }

    @PutMapping("{professor}")
    public void addProfessor(@RequestBody Professor professor) {
        try {
            adminDao.addProfessor(professor);
            System.out.println("Professor Successfully added");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Unable to add professor");

        }
    }

    @PutMapping("{studentId}")
    public void approveStudent(@PathVariable int studentId) {
        try {
            adminDao.approveStudent(studentId);
            System.out.println("Student is Successfully approved");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Student is not approved");
        }
    }

    @PutMapping("{professorId}")
    public void assignCourse(@PathVariable String professorId, String courseCode) {
        try {
            adminDao.assignCourse(professorId, courseCode);
            System.out.println("Course Successfully Assigned");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Professor can't be assigned to given course");
        }
    }

}
