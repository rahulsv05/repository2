package com.crs.lt.model;

public class Catalog {
//    private String catalogId;
//
//    public String getCatalogId() {
//        return catalogId;
//    }
//
//    public void setCatalogId(String catalogId) {
//        this.catalogId = catalogId;
//    }
//
//    private List<Course> courses;
//
//    public List<Course> getCourses() {
//        return courses;
//    }
//
//    public void setCourses(List<Course> courses) {
//        this.courses = courses;
//    }
}
